#!/bin/bash
make -B
./test $1